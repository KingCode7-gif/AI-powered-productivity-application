import { createFileRoute } from "@tanstack/react-router";
import { Sparkles, TrendingUp, Brain, Clock } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AiDisclaimer } from "@/components/ai-disclaimer";

export const Route = createFileRoute("/insights")({
  head: () => ({
    meta: [
      { title: "AI Insights · Lumen AI" },
      { name: "description", content: "Patterns and suggestions from your week." },
    ],
  }),
  component: InsightsPage,
});

const insights = [
  {
    icon: TrendingUp,
    title: "Deep work is up 18%",
    body: "You protected more focus blocks this week. Keep the 9–11am window free to maintain momentum.",
  },
  {
    icon: Clock,
    title: "Meetings cluster on Wednesdays",
    body: "Consider batching 1:1s to free up two larger focus windows on Thursday.",
  },
  {
    icon: Brain,
    title: "Email drafts saved ~2.4 hours",
    body: "Reusing the AI follow-up tone has been your highest-leverage move this month.",
  },
];

function InsightsPage() {
  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 p-4 sm:p-6 lg:p-8">
      <PageHeader
        icon={<Sparkles className="h-5 w-5" />}
        title="AI Insights"
        description="Patterns from your activity and suggestions to improve your week."
      />
      <div className="grid gap-4 md:grid-cols-3">
        {insights.map((i) => (
          <Card key={i.title}>
            <CardHeader>
              <div
                className="grid h-10 w-10 place-items-center rounded-lg text-primary-foreground"
                style={{ backgroundImage: "var(--gradient-primary)" }}
              >
                <i.icon className="h-4 w-4" />
              </div>
              <CardTitle className="mt-3 text-base">{i.title}</CardTitle>
              <CardDescription>{i.body}</CardDescription>
            </CardHeader>
            <CardContent />
          </Card>
        ))}
      </div>
      <AiDisclaimer />
    </div>
  );
}
