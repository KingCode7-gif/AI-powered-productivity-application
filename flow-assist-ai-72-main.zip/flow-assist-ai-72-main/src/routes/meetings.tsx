import { createFileRoute } from "@tanstack/react-router";
import { useState, useRef } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  FileText,
  Sparkles,
  Loader2,
  Upload,
  CheckCircle2,
  ListChecks,
  Clock,
  Copy,
} from "lucide-react";

import { PageHeader } from "@/components/page-header";
import { AiDisclaimer } from "@/components/ai-disclaimer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { summarizeMeeting } from "@/lib/ai.functions";

export const Route = createFileRoute("/meetings")({
  head: () => ({
    meta: [
      { title: "Meeting Summarizer · Lumen AI" },
      { name: "description", content: "Turn meeting notes into structured outcomes with AI." },
    ],
  }),
  component: MeetingsPage,
});

type Result = {
  summary: string;
  keyPoints: string[];
  decisions: string[];
  tasks: { task: string; owner: string; deadline: string }[];
  deadlines: { item: string; date: string }[];
};

function MeetingsPage() {
  const fn = useServerFn(summarizeMeeting);
  const [notes, setNotes] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const mutation = useMutation({
    mutationFn: () => fn({ data: { notes } }),
    onSuccess: (r) => {
      setResult(r as Result);
      toast.success("Meeting analyzed");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const onFile = async (file: File) => {
    const text = await file.text();
    setNotes(text);
    toast.success(`Loaded ${file.name}`);
  };

  const copyAll = async () => {
    if (!result) return;
    const text = [
      `Summary:\n${result.summary}`,
      `\nDecisions:\n${result.decisions.map((d) => `- ${d}`).join("\n")}`,
      `\nTasks:\n${result.tasks.map((t) => `- ${t.task} (${t.owner}, due ${t.deadline})`).join("\n")}`,
      `\nDeadlines:\n${result.deadlines.map((d) => `- ${d.item}: ${d.date}`).join("\n")}`,
    ].join("\n");
    await navigator.clipboard.writeText(text);
    toast.success("Copied summary");
  };

  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 p-4 sm:p-6 lg:p-8">
      <PageHeader
        icon={<FileText className="h-5 w-5" />}
        title="AI Meeting Summarizer"
        description="Paste notes or upload a transcript to extract decisions and action items."
      />

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="text-base">Meeting notes</CardTitle>
            <CardDescription>Long notes welcome — up to 40,000 characters.</CardDescription>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept=".txt,.md,.vtt,.srt"
            hidden
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onFile(f);
              e.target.value = "";
            }}
          />
          <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
            <Upload className="mr-2 h-4 w-4" />
            Upload
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            rows={10}
            placeholder="Paste your transcript or meeting notes here…"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
          <Button
            onClick={() => {
              if (notes.trim().length < 20) {
                toast.error("Add at least 20 characters of notes.");
                return;
              }
              mutation.mutate();
            }}
            disabled={mutation.isPending}
          >
            {mutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Sparkles className="mr-2 h-4 w-4" />
            )}
            Summarize meeting
          </Button>
        </CardContent>
      </Card>

      {result && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Summary</CardTitle>
              <Button variant="ghost" size="sm" onClick={copyAll}>
                <Copy className="mr-2 h-4 w-4" /> Copy all
              </Button>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed text-foreground/90">{result.summary}</p>
              {result.keyPoints.length > 0 && (
                <ul className="mt-4 space-y-1.5 text-sm">
                  {result.keyPoints.map((k, i) => (
                    <li key={i} className="flex gap-2">
                      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-primary" />
                      {k}
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <CheckCircle2 className="h-4 w-4 text-success" /> Decisions made
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {result.decisions.length === 0 ? (
                <p className="text-sm text-muted-foreground">No explicit decisions found.</p>
              ) : (
                result.decisions.map((d, i) => (
                  <div
                    key={i}
                    className="rounded-md border border-border/60 bg-muted/30 px-3 py-2 text-sm"
                  >
                    {d}
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <ListChecks className="h-4 w-4 text-primary" /> Tasks & owners
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {result.tasks.length === 0 ? (
                <p className="text-sm text-muted-foreground">No tasks assigned.</p>
              ) : (
                result.tasks.map((t, i) => (
                  <div key={i} className="rounded-md border border-border/60 px-3 py-2 text-sm">
                    <p className="font-medium">{t.task}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {t.owner} · due {t.deadline}
                    </p>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Clock className="h-4 w-4 text-warning" /> Upcoming deadlines
              </CardTitle>
            </CardHeader>
            <CardContent>
              {result.deadlines.length === 0 ? (
                <p className="text-sm text-muted-foreground">No deadlines mentioned.</p>
              ) : (
                <div className="grid gap-2 sm:grid-cols-2">
                  {result.deadlines.map((d, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between rounded-md border border-border/60 px-3 py-2 text-sm"
                    >
                      <span className="truncate">{d.item}</span>
                      <span className="ml-3 shrink-0 text-xs text-muted-foreground">{d.date}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      <AiDisclaimer />
    </div>
  );
}
