import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { AiDisclaimer } from "@/components/ai-disclaimer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Mail,
  FileText,
  ListChecks,
  ArrowUpRight,
  TrendingUp,
  Clock,
  CheckCircle2,
  Sparkles,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard · Lumen AI" },
      { name: "description", content: "Your AI-powered productivity overview." },
    ],
  }),
  component: Dashboard,
});

const stats = [
  { label: "Tasks completed", value: "24", delta: "+12%", icon: CheckCircle2 },
  { label: "Hours focused", value: "31.5", delta: "+8%", icon: Clock },
  { label: "AI drafts", value: "47", delta: "+23%", icon: Sparkles },
  { label: "Productivity score", value: "86", delta: "+4 pts", icon: TrendingUp },
];

const quickActions = [
  {
    title: "Draft an email",
    description: "Generate a professional email in seconds.",
    href: "/email" as const,
    icon: Mail,
  },
  {
    title: "Summarize a meeting",
    description: "Turn notes into decisions and action items.",
    href: "/meetings" as const,
    icon: FileText,
  },
  {
    title: "Plan your day",
    description: "Prioritize tasks with AI scheduling.",
    href: "/tasks" as const,
    icon: ListChecks,
  },
];

const recentOutputs = [
  { type: "Email", title: "Follow-up: Q3 budget review", time: "2h ago" },
  { type: "Meeting", title: "Product sync — Nov 14", time: "Yesterday" },
  { type: "Plan", title: "Weekly plan — week of Nov 18", time: "2 days ago" },
];

const upcoming = [
  { title: "Send client proposal", due: "Today · 4:00 PM", priority: "P1" },
  { title: "Review design specs", due: "Tomorrow · 10:00 AM", priority: "P2" },
  { title: "1:1 with manager", due: "Wed · 2:00 PM", priority: "P2" },
];

function Dashboard() {
  return (
    <div className="mx-auto w-full max-w-6xl space-y-8 p-4 sm:p-6 lg:p-8">
      <PageHeader
        icon={<LayoutDashboard className="h-5 w-5" />}
        title="Good to see you"
        description="Here's a snapshot of your productivity and AI activity."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="shadow-[var(--shadow-card)]">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <s.icon className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs font-medium text-success">{s.delta}</span>
              </div>
              <p className="mt-3 text-2xl font-semibold tracking-tight">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <section>
        <h2 className="mb-3 text-sm font-semibold text-muted-foreground">Quick actions</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {quickActions.map((a) => (
            <Link key={a.href} to={a.href} className="group">
              <Card className="h-full transition-all hover:-translate-y-0.5 hover:shadow-[var(--shadow-elegant)]">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div
                      className="grid h-10 w-10 place-items-center rounded-lg text-primary-foreground"
                      style={{ backgroundImage: "var(--gradient-primary)" }}
                    >
                      <a.icon className="h-4 w-4" />
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground transition group-hover:text-primary" />
                  </div>
                  <p className="mt-4 font-medium">{a.title}</p>
                  <p className="text-sm text-muted-foreground">{a.description}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent AI outputs</CardTitle>
            <CardDescription>Drafts and summaries you've generated.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {recentOutputs.map((o) => (
              <div
                key={o.title}
                className="flex items-center justify-between rounded-lg border border-border/60 px-3 py-2.5 text-sm"
              >
                <div className="min-w-0">
                  <p className="truncate font-medium">{o.title}</p>
                  <p className="text-xs text-muted-foreground">{o.type}</p>
                </div>
                <span className="text-xs text-muted-foreground">{o.time}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-base">Upcoming tasks</CardTitle>
              <CardDescription>Your next priorities.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/tasks">Plan day</Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-2">
            {upcoming.map((u) => (
              <div
                key={u.title}
                className="flex items-center justify-between rounded-lg border border-border/60 px-3 py-2.5 text-sm"
              >
                <div className="min-w-0">
                  <p className="truncate font-medium">{u.title}</p>
                  <p className="text-xs text-muted-foreground">{u.due}</p>
                </div>
                <span className="rounded-md bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                  {u.priority}
                </span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <AiDisclaimer />
    </div>
  );
}
