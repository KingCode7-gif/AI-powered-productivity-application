import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Mail, Copy, RefreshCcw, Wand2, Sparkles, Loader2, Download } from "lucide-react";

import { PageHeader } from "@/components/page-header";
import { AiDisclaimer } from "@/components/ai-disclaimer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { generateEmail } from "@/lib/ai.functions";

export const Route = createFileRoute("/email")({
  head: () => ({
    meta: [
      { title: "Email Generator · Lumen AI" },
      { name: "description", content: "Generate and refine professional emails with AI." },
    ],
  }),
  component: EmailPage,
});

type Tone = "formal" | "friendly" | "persuasive" | "apologetic" | "follow-up";
type Action = "generate" | "rewrite" | "improve" | "shorten" | "professional";

function EmailPage() {
  const fn = useServerFn(generateEmail);
  const [recipient, setRecipient] = useState("");
  const [purpose, setPurpose] = useState("");
  const [keyPoints, setKeyPoints] = useState("");
  const [tone, setTone] = useState<Tone>("formal");
  const [output, setOutput] = useState("");

  const mutation = useMutation({
    mutationFn: (action: Action) =>
      fn({
        data: {
          recipient,
          purpose,
          keyPoints,
          tone,
          action,
          existing: action === "generate" ? "" : output,
        },
      }),
    onSuccess: (res) => {
      setOutput(res.email);
      toast.success("Email ready");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const run = (action: Action) => {
    if (action === "generate" && !purpose.trim()) {
      toast.error("Tell the AI what the email is about.");
      return;
    }
    if (action !== "generate" && !output.trim()) {
      toast.error("Generate an email first.");
      return;
    }
    mutation.mutate(action);
  };

  const copy = async () => {
    await navigator.clipboard.writeText(output);
    toast.success("Copied to clipboard");
  };

  const download = () => {
    const blob = new Blob([output], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "email.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  const loading = mutation.isPending;

  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 p-4 sm:p-6 lg:p-8">
      <PageHeader
        icon={<Mail className="h-5 w-5" />}
        title="Smart Email Generator"
        description="Draft polished workplace emails from a quick brief."
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Brief</CardTitle>
            <CardDescription>Tell the AI what to write.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="recipient">Recipient</Label>
              <Input
                id="recipient"
                placeholder="e.g. Client, Manager, Engineering team"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="purpose">Purpose *</Label>
              <Textarea
                id="purpose"
                rows={3}
                placeholder="Follow up on Q3 budget review and request next steps."
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="key">Key points</Label>
              <Textarea
                id="key"
                rows={4}
                placeholder="• Deadline is Friday\n• Mention the new proposal\n• Ask for confirmation"
                value={keyPoints}
                onChange={(e) => setKeyPoints(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label>Tone</Label>
              <Select value={tone} onValueChange={(v) => setTone(v as Tone)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="formal">Formal</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="persuasive">Persuasive</SelectItem>
                  <SelectItem value="apologetic">Apologetic</SelectItem>
                  <SelectItem value="follow-up">Follow-up</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              className="w-full"
              onClick={() => run("generate")}
              disabled={loading}
            >
              {loading && mutation.variables === "generate" ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="mr-2 h-4 w-4" />
              )}
              Generate email
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="text-base">Draft</CardTitle>
              <CardDescription>Edit freely. Use AI to refine.</CardDescription>
            </div>
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" onClick={copy} disabled={!output}>
                <Copy className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={download} disabled={!output}>
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              rows={16}
              placeholder="Your AI-generated email will appear here…"
              value={output}
              onChange={(e) => setOutput(e.target.value)}
              className="font-mono text-sm"
            />
            <div className="flex flex-wrap gap-2">
              {(
                [
                  { a: "rewrite", label: "Rewrite", icon: RefreshCcw },
                  { a: "improve", label: "Improve clarity", icon: Wand2 },
                  { a: "shorten", label: "Shorten", icon: Wand2 },
                  { a: "professional", label: "More professional", icon: Wand2 },
                ] as { a: Action; label: string; icon: typeof Wand2 }[]
              ).map(({ a, label, icon: Icon }) => (
                <Button
                  key={a}
                  variant="outline"
                  size="sm"
                  onClick={() => run(a)}
                  disabled={loading || !output}
                >
                  {loading && mutation.variables === a ? (
                    <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Icon className="mr-2 h-3.5 w-3.5" />
                  )}
                  {label}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <AiDisclaimer />
    </div>
  );
}
