import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { ListChecks, Sparkles, Loader2, Calendar as CalIcon, Flame, Lightbulb } from "lucide-react";

import { PageHeader } from "@/components/page-header";
import { AiDisclaimer } from "@/components/ai-disclaimer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { planTasks } from "@/lib/ai.functions";

export const Route = createFileRoute("/tasks")({
  head: () => ({
    meta: [
      { title: "Task Planner · Lumen AI" },
      { name: "description", content: "AI-prioritized daily and weekly schedules." },
    ],
  }),
  component: TasksPage,
});

type Plan = {
  priorities: {
    title: string;
    priority: "P1" | "P2" | "P3";
    importance: "high" | "medium" | "low";
    urgency: "high" | "medium" | "low";
    estimateMinutes: number;
  }[];
  agenda: { time: string; title: string; note: string }[];
  recommendations: string[];
};

const priorityStyles: Record<string, string> = {
  P1: "bg-destructive/10 text-destructive",
  P2: "bg-warning/15 text-warning-foreground",
  P3: "bg-muted text-muted-foreground",
};

function TasksPage() {
  const fn = useServerFn(planTasks);
  const [tasks, setTasks] = useState("");
  const [goals, setGoals] = useState("");
  const [horizon, setHorizon] = useState<"day" | "week">("day");
  const [plan, setPlan] = useState<Plan | null>(null);

  const mutation = useMutation({
    mutationFn: () => fn({ data: { tasks, goals, horizon } }),
    onSuccess: (p) => {
      setPlan(p as Plan);
      toast.success("Plan ready");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 p-4 sm:p-6 lg:p-8">
      <PageHeader
        icon={<ListChecks className="h-5 w-5" />}
        title="AI Task Planner"
        description="Drop in your tasks — get a prioritized, time-blocked schedule."
      />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">What's on your plate?</CardTitle>
          <CardDescription>List tasks one per line. Add deadlines or context inline.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="tasks">Tasks *</Label>
              <Textarea
                id="tasks"
                rows={8}
                placeholder={"Prepare board deck (due Fri)\nReview PR #482\nDraft hiring plan\n1:1 prep — Sara"}
                value={tasks}
                onChange={(e) => setTasks(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="goals">Goals for this period</Label>
              <Textarea
                id="goals"
                rows={8}
                placeholder="Ship the new onboarding flow. Protect 2 hours/day for deep work."
                value={goals}
                onChange={(e) => setGoals(e.target.value)}
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Tabs value={horizon} onValueChange={(v) => setHorizon(v as "day" | "week")}>
              <TabsList>
                <TabsTrigger value="day">Daily</TabsTrigger>
                <TabsTrigger value="week">Weekly</TabsTrigger>
              </TabsList>
            </Tabs>
            <Button
              onClick={() => {
                if (tasks.trim().length < 5) {
                  toast.error("Add a few tasks first.");
                  return;
                }
                mutation.mutate();
              }}
              disabled={mutation.isPending}
            >
              {mutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="mr-2 h-4 w-4" />
              )}
              Build {horizon === "day" ? "daily" : "weekly"} plan
            </Button>
          </div>
        </CardContent>
      </Card>

      {plan && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <CalIcon className="h-4 w-4 text-primary" />{" "}
                {horizon === "day" ? "Daily agenda" : "Weekly agenda"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="divide-y divide-border/60">
                {plan.agenda.map((a, i) => (
                  <div key={i} className="grid grid-cols-[88px_1fr] gap-3 py-3 text-sm">
                    <div className="font-mono text-xs text-muted-foreground">{a.time}</div>
                    <div className="min-w-0">
                      <p className="truncate font-medium">{a.title}</p>
                      {a.note && (
                        <p className="mt-0.5 text-xs text-muted-foreground">{a.note}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Flame className="h-4 w-4 text-destructive" /> Priorities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {plan.priorities.map((p, i) => (
                <div
                  key={i}
                  className="rounded-md border border-border/60 px-3 py-2 text-sm"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="min-w-0 truncate font-medium">{p.title}</p>
                    <span
                      className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-semibold ${priorityStyles[p.priority]}`}
                    >
                      {p.priority}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    Importance: {p.importance} · Urgency: {p.urgency} · ~{p.estimateMinutes}m
                  </p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Lightbulb className="h-4 w-4 text-warning" /> Productivity recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="grid gap-2 sm:grid-cols-3">
                {plan.recommendations.map((r, i) => (
                  <li
                    key={i}
                    className="rounded-md border border-border/60 bg-muted/30 px-3 py-2 text-sm"
                  >
                    {r}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      )}

      <AiDisclaimer />
    </div>
  );
}
