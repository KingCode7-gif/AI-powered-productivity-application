import { createFileRoute } from "@tanstack/react-router";
import { HelpCircle } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "Help & Support · Lumen AI" },
      { name: "description", content: "Get answers about using Lumen AI." },
    ],
  }),
  component: HelpPage,
});

const faqs = [
  {
    q: "How does the AI generate emails?",
    a: "Lumen AI uses a large language model to draft emails from the brief you provide. You can refine tone, clarity, and length with one click.",
  },
  {
    q: "Is my data private?",
    a: "Your inputs are sent securely to the AI provider to generate a response and are not stored beyond your active session.",
  },
  {
    q: "Can I edit AI outputs?",
    a: "Yes. Every output is fully editable. Use the refine actions to iterate or rewrite by hand.",
  },
  {
    q: "What if the AI gets something wrong?",
    a: "Always review AI output before sending or acting on it. Use the regenerate or rewrite options if something is off.",
  },
];

function HelpPage() {
  return (
    <div className="mx-auto w-full max-w-3xl space-y-6 p-4 sm:p-6 lg:p-8">
      <PageHeader
        icon={<HelpCircle className="h-5 w-5" />}
        title="Help & Support"
        description="Answers, tips, and best practices for working with Lumen AI."
      />
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Frequently asked</CardTitle>
          <CardDescription>Quick answers to common questions.</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible>
            {faqs.map((f, i) => (
              <AccordionItem key={i} value={`item-${i}`}>
                <AccordionTrigger>{f.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
