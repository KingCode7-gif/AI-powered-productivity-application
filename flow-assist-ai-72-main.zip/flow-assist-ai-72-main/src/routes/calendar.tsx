import { createFileRoute } from "@tanstack/react-router";
import { Calendar as CalIcon } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/calendar")({
  head: () => ({
    meta: [
      { title: "Calendar · Lumen AI" },
      { name: "description", content: "Your week at a glance." },
    ],
  }),
  component: CalendarPage,
});

const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const sample: Record<string, { time: string; title: string }[]> = {
  Mon: [{ time: "10:00", title: "Standup" }, { time: "14:00", title: "Design review" }],
  Tue: [{ time: "09:30", title: "1:1 with Sara" }],
  Wed: [{ time: "11:00", title: "Product sync" }, { time: "15:30", title: "Deep work" }],
  Thu: [{ time: "13:00", title: "Client demo" }],
  Fri: [{ time: "10:00", title: "Retro" }, { time: "16:00", title: "Send weekly update" }],
  Sat: [],
  Sun: [],
};

function CalendarPage() {
  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 p-4 sm:p-6 lg:p-8">
      <PageHeader
        icon={<CalIcon className="h-5 w-5" />}
        title="Calendar"
        description="A simple weekly view of your meetings and focus blocks."
      />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-7">
        {days.map((d) => (
          <Card key={d}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">{d}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {sample[d].length === 0 ? (
                <p className="text-xs text-muted-foreground">Open</p>
              ) : (
                sample[d].map((e, i) => (
                  <div key={i} className="rounded-md border border-border/60 px-2 py-1.5 text-xs">
                    <p className="font-mono text-[10px] text-muted-foreground">{e.time}</p>
                    <p className="font-medium">{e.title}</p>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
