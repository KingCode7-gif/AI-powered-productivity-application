import { createFileRoute } from "@tanstack/react-router";
import { Settings as SettingsIcon, ShieldCheck } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings · Lumen AI" },
      { name: "description", content: "Manage your workspace, AI behavior, and privacy." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <div className="mx-auto w-full max-w-3xl space-y-6 p-4 sm:p-6 lg:p-8">
      <PageHeader
        icon={<SettingsIcon className="h-5 w-5" />}
        title="Settings"
        description="Manage your profile, AI assistance, and privacy preferences."
      />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Profile</CardTitle>
          <CardDescription>How you appear inside Lumen AI.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="grid gap-2">
            <Label htmlFor="name">Full name</Label>
            <Input id="name" defaultValue="Alex Morgan" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="email">Work email</Label>
            <Input id="email" type="email" defaultValue="alex@company.com" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">AI assistance</CardTitle>
          <CardDescription>Control how AI shows up in your workflow.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            ["Smart email suggestions", "Get tone and clarity suggestions while drafting."],
            ["Meeting auto-summaries", "Summarize transcripts as soon as they're uploaded."],
            ["Daily planning nudges", "Send a morning briefing with your top priorities."],
          ].map(([title, desc], i) => (
            <div key={i} className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-medium">{title}</p>
                <p className="text-xs text-muted-foreground">{desc}</p>
              </div>
              <Switch defaultChecked={i !== 2} />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ShieldCheck className="h-4 w-4 text-primary" /> Privacy & transparency
          </CardTitle>
          <CardDescription>You're always in control of your AI outputs.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <p>
            Your inputs are only used to generate the requested output. We do not store your meeting
            notes, emails, or task lists beyond your active session unless you save them.
          </p>
          <Separator />
          <p>
            AI-generated content is designed to assist productivity and should be reviewed by users
            before making important decisions or sending professional communications.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
