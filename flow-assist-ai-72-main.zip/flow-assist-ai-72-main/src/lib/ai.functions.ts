import { createServerFn } from "@tanstack/react-start";
import { generateText, Output } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

const MODEL = "google/gemini-3-flash-preview";

function getGateway() {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  return createLovableAiGatewayProvider(key);
}

function mapError(e: unknown): never {
  const msg = e instanceof Error ? e.message : String(e);
  if (msg.includes("429")) throw new Error("Rate limit reached. Please try again in a moment.");
  if (msg.includes("402")) throw new Error("AI credits exhausted. Please add credits in your workspace billing.");
  throw new Error(msg || "AI request failed");
}

/* ---------------- Email Generator ---------------- */
const EmailInput = z.object({
  recipient: z.string().max(200).default(""),
  purpose: z.string().min(1).max(1000),
  keyPoints: z.string().max(2000).default(""),
  tone: z.enum(["formal", "friendly", "persuasive", "apologetic", "follow-up"]),
  action: z
    .enum(["generate", "rewrite", "improve", "shorten", "professional"])
    .default("generate"),
  existing: z.string().max(8000).default(""),
});

export const generateEmail = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => EmailInput.parse(d))
  .handler(async ({ data }) => {
    try {
      const gateway = getGateway();
      const actionInstruction: Record<string, string> = {
        generate: "Write a new professional workplace email.",
        rewrite: "Rewrite the following draft, keeping intent but improving phrasing.",
        improve: "Improve clarity, structure and flow of the following draft.",
        shorten: "Shorten the following draft while preserving its meaning.",
        professional: "Rewrite the draft to sound more professional and polished.",
      };
      const prompt = [
        actionInstruction[data.action],
        `Tone: ${data.tone}.`,
        data.recipient && `Recipient: ${data.recipient}.`,
        `Purpose: ${data.purpose}.`,
        data.keyPoints && `Key points: ${data.keyPoints}.`,
        data.existing && `Existing draft:\n${data.existing}`,
        "Return ONLY the email — include a subject line on the first line as 'Subject: ...' then a blank line, then the body. No commentary.",
      ]
        .filter(Boolean)
        .join("\n");

      const { text } = await generateText({
        model: gateway(MODEL),
        prompt,
        system:
          "You are a senior executive assistant who writes crisp, professional workplace emails.",
      });
      return { email: text.trim() };
    } catch (e) {
      mapError(e);
    }
  });

/* ---------------- Meeting Summarizer ---------------- */
const MeetingInput = z.object({
  notes: z.string().min(20).max(40000),
});

export const summarizeMeeting = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => MeetingInput.parse(d))
  .handler(async ({ data }) => {
    try {
      const gateway = getGateway();
      const { output } = await generateText({
        model: gateway(MODEL),
        system:
          "You analyze meeting notes and extract structured outcomes. Be precise and concise.",
        prompt: `Analyze the meeting notes/transcript below and extract structured information.\n\n---\n${data.notes}\n---`,
        output: Output.object({
          schema: z.object({
            summary: z.string(),
            keyPoints: z.array(z.string()),
            decisions: z.array(z.string()),
            tasks: z.array(
              z.object({
                task: z.string(),
                owner: z.string(),
                deadline: z.string(),
              }),
            ),
            deadlines: z.array(
              z.object({ item: z.string(), date: z.string() }),
            ),
          }),
        }),
      });
      return output;
    } catch (e) {
      mapError(e);
    }
  });

/* ---------------- Task Planner ---------------- */
const PlannerInput = z.object({
  tasks: z.string().min(5).max(8000),
  goals: z.string().max(2000).default(""),
  horizon: z.enum(["day", "week"]).default("day"),
});

export const planTasks = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => PlannerInput.parse(d))
  .handler(async ({ data }) => {
    try {
      const gateway = getGateway();
      const { output } = await generateText({
        model: gateway(MODEL),
        system:
          "You are a productivity coach. Prioritize work using urgency/importance and produce realistic, time-blocked schedules.",
        prompt: `Build a ${data.horizon === "day" ? "daily" : "weekly"} plan.\n\nTasks:\n${data.tasks}\n\nGoals: ${data.goals || "(none provided)"}\n\nProduce prioritized tasks (P1/P2/P3), a time-blocked agenda for the ${data.horizon}, and 3 productivity recommendations.`,
        output: Output.object({
          schema: z.object({
            priorities: z.array(
              z.object({
                title: z.string(),
                priority: z.enum(["P1", "P2", "P3"]),
                importance: z.enum(["high", "medium", "low"]),
                urgency: z.enum(["high", "medium", "low"]),
                estimateMinutes: z.number(),
              }),
            ),
            agenda: z.array(
              z.object({
                time: z.string(),
                title: z.string(),
                note: z.string(),
              }),
            ),
            recommendations: z.array(z.string()),
          }),
        }),
      });
      return output;
    } catch (e) {
      mapError(e);
    }
  });
